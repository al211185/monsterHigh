//
//  MonsterCollectionViewCell.swift
//  MonsterhIGH
//
//  Created by alumno on 11/8/24.
//

import UIKit

class MonsterCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var foto_de_perfil: UIImageView!
    @IBOutlet weak var Nombre: UILabel!
    @IBOutlet weak var Padres: UILabel!
}

